
import { useNavigate, Navigate } from "react-router-dom";
import { useEffect } from "react";

const Index = () => {
  return <Navigate to="/" replace />;
};

export default Index;
